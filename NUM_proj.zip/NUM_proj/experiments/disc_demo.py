from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from minimax import minimax_disc
from minimax.cheb import affine_to_cheb, clenshaw

DEGREE = 50
SIZES = [1000, 5000]
NOISE_LEVELS = [0.0, 1e-4, 1e-3]


def target_function(x: np.ndarray) -> np.ndarray:
    return np.cos(5.0 * x) + 0.25 * np.sin(11.0 * x)


def summarize_result(name: str, y: np.ndarray, x: np.ndarray, res) -> tuple[float, float]:
    x2t, _ = affine_to_cheb(-1.0, 1.0)
    approx = clenshaw(res.coeffs, x2t(x))
    sup_err = float(np.max(np.abs(y - approx)))
    print(f"{name:<10s} tau={res.t:.3e}  sup|r|={sup_err:.3e}  nit={res.nit}")
    return sup_err, approx


def run_disc_demo(seed: int = 0) -> None:
    rng = np.random.default_rng(seed)
    fig, axes = plt.subplots(len(SIZES), len(NOISE_LEVELS), figsize=(15, 6), sharex=True, sharey=True)
    for i, N in enumerate(SIZES):
        x = np.linspace(-1.0, 1.0, N)
        clean = target_function(x)
        for j, delta in enumerate(NOISE_LEVELS):
            noise = rng.uniform(-delta, delta, size=N)
            y = clean + noise
            print(f"\nN={N}, delta={delta:.1e}")
            res_lp = minimax_disc(x, y, DEGREE, a=-1.0, b=1.0, use_lawson=False)
            res_lawson = minimax_disc(x, y, DEGREE, a=-1.0, b=1.0, use_lawson=True)
            sup_lp, approx_lp = summarize_result("LP", y, x, res_lp)
            sup_lawson, approx_lawson = summarize_result("Lawson", y, x, res_lawson)
            axes[i, j].hist(
                y - approx_lp,
                bins=40,
                alpha=0.6,
                label="LP",
            )
            axes[i, j].hist(
                y - approx_lawson,
                bins=40,
                alpha=0.6,
                label="Lawson",
            )
            axes[i, j].set_title(f"N={N}, δ={delta:.0e}")
            axes[i, j].grid(True, alpha=0.2)
            if i == len(SIZES) - 1:
                axes[i, j].set_xlabel("residual")
            if j == 0:
                axes[i, j].set_ylabel("count")
            if i == 0 and j == len(NOISE_LEVELS) - 1:
                axes[i, j].legend()
    fig.tight_layout()
    plt.show()


if __name__ == "__main__":
    run_disc_demo()
