from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

from minimax import remez_minimax
from minimax.cheb import poly_eval_on_ab

EVENT_COLORS = {
    "lp_init": "#2ca02c",
    "lp_refresh": "#ff7f0e",
    "fallback_restart": "#d62728",
}

FUNCS = {
    "exp(x)": (np.exp, 0.03),
    "|x|": (np.abs, 0.05),
    "sin(20x)": (lambda x: np.sin(20.0 * x), 0.03),
}
DEGREES = [20, 50, 100]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Continuous minimax demo (Remez + spectral extrema)")
    parser.add_argument("--lawson-steps", type=int, default=5, help="Lawson polish steps (≤10)")
    parser.add_argument("--no-lp-init", action="store_true", help="Disable LP initialization")
    parser.add_argument("--grid-M", type=int, default=4097, help="Spectral grid size for extrema search")
    parser.add_argument("--outdir", type=Path, help="Directory to save figures (headless mode)")
    parser.add_argument("--no-show", action="store_true", help="Do not open matplotlib windows")
    parser.add_argument(
        "--yscale",
        choices=["linear", "symlog", "logabs"],
        default="symlog",
        help="Right-plot y-scale: linear/symlog/logabs(|r|)",
    )
    parser.add_argument("--linthresh", type=float, default=1e-8, help="symlog linthresh")
    return parser.parse_args()


def run_cont_demo(
    lawson_steps: int,
    use_lp_init: bool,
    grid_M: int,
    outdir: Path | None,
    show: bool,
    yscale: str = "symlog",
    linthresh: float = 1e-8,
) -> None:
    if outdir:
        outdir.mkdir(parents=True, exist_ok=True)
    for name, (func, tol) in FUNCS.items():
        fig, axes = plt.subplots(1, 2, figsize=(12, 4))
        table_rows = []
        for n in DEGREES:
            result = remez_minimax(
                func,
                n,
                a=-1.0,
                b=1.0,
                eq_tol=tol,
                use_lp_init=use_lp_init,
                lawson_polish_steps=lawson_steps,
            )
            axes[0].semilogy(result.history["E"], label=f"n={n}")
            peaks_x, _ = result.history["extremals"][-1]
            # use true residuals (not the stored padded values) to gauge alternation
            peaks_r_true = func(peaks_x) - poly_eval_on_ab(result.coeffs, peaks_x, -1.0, 1.0)
            abs_r = np.abs(peaks_r_true)
            eq_dev = (abs_r.max() - abs_r.min()) / max(abs_r.mean(), 1e-15)
            table_rows.append(
                [
                    f"n={n}",
                    f"{result.E:.2e}",
                    f"{eq_dev*100:.1f}%",
                    f"{abs_r.min():.2e}/{abs_r.max():.2e}",
                ]
            )
        axes[0].set_title(f"{name} |E| history")
        axes[0].set_xlabel("Remez iteration")
        axes[0].set_ylabel("max |r|")
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        axes[1].axis("off")
        table = axes[1].table(
            cellText=table_rows,
            colLabels=["n", "E_grid", "eq dev", "min/max |r|"],
            loc="center",
            cellLoc="center",
            colWidths=[0.2, 0.28, 0.22, 0.3],
        )
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1.1, 1.25)
        # header styling
        for (row, col), cell in table.get_celld().items():
            # remove full grid; only a few separators
            cell.visible_edges = "open"
            cell.set_linewidth(0.0)
            if row == 0:
                cell.set_text_props(weight="bold")
                cell.set_facecolor("#f0f0f0")
                cell.visible_edges = "B"
                cell.set_linewidth(0.8)
            elif row % 2 == 0:
                cell.set_facecolor("#fafafa")
        axes[1].set_title(f"{name} equioscillation summary")
        # mark events on |E| history
        events = result.history.get("events", [])
        for idx, evt_list in enumerate(events):
            for evt in evt_list:
                color = EVENT_COLORS.get(evt, "#7f7f7f")
                axes[0].axvline(idx, color=color, linestyle="--", alpha=0.35)
        if EVENT_COLORS:
            base_handles, base_labels = axes[0].get_legend_handles_labels()
            event_handles = [
                plt.Line2D([0], [0], color=color, linestyle="--", label=label)
                for label, color in EVENT_COLORS.items()
            ]
            handles = base_handles + event_handles
            labels = base_labels + list(EVENT_COLORS.keys())
            axes[0].legend(handles, labels, loc="upper right")
        fig.tight_layout()
        if outdir:
            safe_name = name.replace("|", "abs").replace("(", "").replace(")", "").replace("/", "_")
            fig.savefig(outdir / f"{safe_name}.png", dpi=200)
        if not show:
            plt.close(fig)
    if show:
        plt.show()


if __name__ == "__main__":
    args = parse_args()
    run_cont_demo(
        lawson_steps=min(args.lawson_steps, 10),
        use_lp_init=not args.no_lp_init,
        grid_M=args.grid_M,
        outdir=args.outdir,
        show=not args.no_show,
        yscale=args.yscale,
        linthresh=args.linthresh,
    )
