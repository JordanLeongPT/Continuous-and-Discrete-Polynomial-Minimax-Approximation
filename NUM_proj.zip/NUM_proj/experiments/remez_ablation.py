from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import matplotlib.pyplot as plt

from minimax import remez_minimax
from minimax.cheb import poly_eval_on_ab


FUNC_MAP: Dict[str, Tuple] = {
    "exp": (np.exp, 0.03),
    "abs": (np.abs, 0.05),
    "sin20": (lambda x: np.sin(20.0 * x), 0.03),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Ablation experiments for continuous Remez minimax solver",
    )
    parser.add_argument("--func", choices=list(FUNC_MAP.keys()), default="exp")
    parser.add_argument("--degree", type=int, default=10)
    parser.add_argument("--a", type=float, default=-1.0)
    parser.add_argument("--b", type=float, default=1.0)
    parser.add_argument("--max-iter", type=int, default=80)
    parser.add_argument("--outdir", type=Path, default=Path("experiments/ablation"))
    return parser.parse_args()


def run_ablation(func_key: str, n: int, a: float, b: float, max_iter: int, outdir: Path) -> None:
    f, eq_tol_default = FUNC_MAP[func_key]
    outdir.mkdir(parents=True, exist_ok=True)

    configs = {
        "baseline": dict(use_lp_init=True, lawson_polish_steps=5, tolE=1e-4),
        "no_lp_init": dict(use_lp_init=False, lawson_polish_steps=5, tolE=1e-4),
        "no_lawson": dict(use_lp_init=True, lawson_polish_steps=0, tolE=1e-4),
        "no_lp_no_lawson": dict(use_lp_init=False, lawson_polish_steps=0, tolE=1e-4),
        "tolE_1e-2": dict(use_lp_init=True, lawson_polish_steps=5, tolE=1e-2),
        "tolE_1e-1": dict(use_lp_init=True, lawson_polish_steps=5, tolE=1e-1),
    }

    histories: Dict[str, np.ndarray] = {}
    final_E: Dict[str, float] = {}

    for name, cfg in configs.items():
        print(f"Running config={name} ...")
        res = remez_minimax(
            f,
            n,
            a=a,
            b=b,
            eq_tol=eq_tol_default,
            tolE=cfg["tolE"],
            max_iter=max_iter,
            use_lp_init=cfg["use_lp_init"],
            lawson_polish_steps=cfg["lawson_polish_steps"],
        )
        histories[name] = np.array(res.history["E"], dtype=float)
        final_E[name] = float(res.E)

    # plot E-history comparison
    fig, ax = plt.subplots(figsize=(7, 5))
    for name, E_hist in histories.items():
        iters = np.arange(1, len(E_hist) + 1)
        ax.semilogy(iters, E_hist, marker="o", ms=3, label=f"{name} (E={final_E[name]:.1e})")
    ax.set_xlabel("Remez iteration")
    ax.set_ylabel("max |f - p|")
    ax.set_title(f"Remez ablation, f={func_key}, n={n}")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()

    fig_path = outdir / f"remez_ablation_{func_key}_n{n}.png"
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)

    # save residual curves for each config on a common dense grid
    x = np.linspace(a, b, 2000)
    y = f(x)
    for name, cfg in configs.items():
        res = remez_minimax(
            f,
            n,
            a=a,
            b=b,
            eq_tol=eq_tol_default,
            tolE=cfg["tolE"],
            max_iter=max_iter,
            use_lp_init=cfg["use_lp_init"],
            lawson_polish_steps=cfg["lawson_polish_steps"],
        )
        p = poly_eval_on_ab(res.coeffs, x, a, b)
        r = p - y
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(x, r, lw=1.5)
        ax.axhline(0.0, color="k", linewidth=0.8, alpha=0.5)
        ax.set_xlabel("x")
        ax.set_ylabel("p(x) - f(x)")
        ax.set_title(f"Residual, config={name}, f={func_key}, n={n}")
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(outdir / f"residual_{func_key}_n{n}_{name}.png", dpi=200)
        plt.close(fig)


def main() -> None:
    args = parse_args()
    run_ablation(args.func, args.degree, args.a, args.b, args.max_iter, args.outdir)


if __name__ == "__main__":
    main()

