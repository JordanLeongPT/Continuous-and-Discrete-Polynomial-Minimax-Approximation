from __future__ import annotations

import argparse
import time
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Tuple

import numpy as np
import matplotlib.pyplot as plt

from minimax import minimax_disc
from minimax.cheb import poly_eval_on_ab

FunctionSpec = Tuple[Callable[[np.ndarray], np.ndarray], float]

FUNCS: Dict[str, FunctionSpec] = {
    "exp(x)": (np.exp, 0.03),
    "|x|": (np.abs, 0.05),
    "sin(20x)": (lambda x: np.sin(20.0 * x), 0.03),
}


def _residuals(coeffs: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
    approx = poly_eval_on_ab(coeffs, x, -1.0, 1.0)
    return y - approx


def run_disc_report(
    Ns: Iterable[int],
    degree: int,
    delta: float,
    logs: Path,
    figs: Path,
    time_budget: float,
    seed: int,
    max_iter: int = 5000,
) -> Tuple[Path, Path, Path]:
    logs.mkdir(parents=True, exist_ok=True)
    figs.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    start = time.perf_counter()
    summary_path = logs / "disc_summary.md"
    timing_path = logs / "disc_timing.txt"
    csv_path = logs / "disc_summary.csv"
    records: List[Dict[str, object]] = []
    timings: List[str] = []

    for name, (func, _) in FUNCS.items():
        for N in Ns:
            elapsed = time.perf_counter() - start
            if elapsed > time_budget:
                timings.append(f"Time budget exceeded ({elapsed:.2f}s); skipping remaining cases")
                break
            x = np.linspace(-1.0, 1.0, N)
            y_clean = func(x)
            t0 = time.perf_counter()
            res_clean = minimax_disc(x, y_clean, degree, a=-1.0, b=1.0, use_lawson=True, max_iter=max_iter)
            runtime_clean = time.perf_counter() - t0
            res_clean_vals = _residuals(res_clean.coeffs, x, y_clean)

            y_noise = y_clean + rng.uniform(-delta, delta, size=N)
            t1 = time.perf_counter()
            res_noise = minimax_disc(x, y_noise, degree, a=-1.0, b=1.0, use_lawson=True, max_iter=max_iter)
            runtime_noise = time.perf_counter() - t1
            res_noise_vals = _residuals(res_noise.coeffs, x, y_noise)
            t_robust = res_noise.t + delta

            fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=False)
            axes[0].hist(res_clean_vals, bins=50, alpha=0.8, color="#1f77b4")
            axes[0].set_title(f"{name} N={N} clean")
            axes[0].set_xlabel("residual")
            axes[0].set_ylabel("count")
            axes[1].hist(res_noise_vals, bins=50, alpha=0.8, color="#ff7f0e")
            axes[1].set_title(f"{name} N={N} noisy")
            axes[1].set_xlabel("residual")
            fig.tight_layout()
            fig_path = figs / f"{name.replace('|', 'abs').replace('(', '').replace(')', '').replace('/', '_')}_N{N}.png"
            fig.savefig(fig_path, dpi=160)
            plt.close(fig)

            records.append(
                {
                    "function": name,
                    "N": N,
                    "degree": degree,
                    "t_clean": res_clean.t,
                    "t_noise": res_noise.t,
                    "t_robust": t_robust,
                    "nit_clean": res_clean.nit,
                    "nit_noise": res_noise.nit,
                    "runtime_clean": runtime_clean,
                    "runtime_noise": runtime_noise,
                }
            )
            timings.append(
                f"{name} N={N}: clean {runtime_clean:.2f}s, noisy {runtime_noise:.2f}s"
            )
    # write csv/md
    if records:
        import csv as _csv

        with csv_path.open("w", newline="") as f:
            writer = _csv.DictWriter(f, fieldnames=list(records[0].keys()))
            writer.writeheader()
            writer.writerows(records)
        with summary_path.open("w") as f:
            f.write("| Function | N | n | t* | t* noisy | t*+δ | nit(clean/noisy) | runtime(s) |\n")
            f.write("| --- | ---: | ---: | ---: | ---: | ---: | --- | --- |\n")
            for rec in records:
                f.write(
                    f"| {rec['function']} | {rec['N']} | {rec['degree']} | {rec['t_clean']:.6e} | "
                    f"{rec['t_noise']:.6e} | {rec['t_robust']:.6e} | {rec['nit_clean']}/{rec['nit_noise']} | "
                    f"{rec['runtime_clean']:.2f}/{rec['runtime_noise']:.2f} |\n"
                )
    with timing_path.open("w") as f:
        for line in timings:
            f.write(line + "\n")
        f.write(f"Total elapsed: {time.perf_counter() - start:.2f}s\n")
    return summary_path, csv_path, timing_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Discrete minimax report")
    parser.add_argument("--Ns", type=int, nargs="*", default=[1000, 5000])
    parser.add_argument("--degree", type=int, default=50)
    parser.add_argument("--delta", type=float, default=1e-3)
    parser.add_argument("--logs", type=Path, default=Path("experiments/logs"))
    parser.add_argument("--figs", type=Path, default=Path("experiments/figs"))
    parser.add_argument("--time-budget", type=float, default=30.0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--max-iter", type=int, default=5000, help="LP solver iteration cap for minimax_disc")
    parser.add_argument("--bins", type=int, default=120)
    parser.add_argument(
        "--sample-mode",
        choices=["uniform", "cheb", "random"],
        default="uniform",
        help="Sampling strategy for x grid",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary_path, csv_path, timing_path = run_disc_report(
        Ns=args.Ns,
        degree=args.degree,
        delta=args.delta,
        logs=args.logs,
        figs=args.figs,
        time_budget=args.time_budget,
        seed=args.seed,
    )
    print(f"Summary markdown: {summary_path}")
    print(f"Summary CSV: {csv_path}")
    print(f"Timing log: {timing_path}")


if __name__ == "__main__":
    main()
