"""Experiment scripts for minimax demos."""

