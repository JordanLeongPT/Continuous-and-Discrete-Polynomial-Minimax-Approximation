from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Tuple

import numpy as np

from minimax import remez_minimax
from minimax.utils import equioscillation_ok

FunctionSpec = Tuple[Callable[[np.ndarray], np.ndarray], float]

FUNCS: Dict[str, FunctionSpec] = {
    "exp(x)": (np.exp, 0.03),
    "|x|": (np.abs, 0.05),
    "sin(20x)": (lambda x: np.sin(20.0 * x), 0.03),
}


def _percent_spread(values: np.ndarray) -> float:
    mags = np.abs(values)
    if mags.size == 0 or np.allclose(mags, 0):
        return float("nan")
    return float((mags.max() - mags.min()) / np.maximum(mags.mean(), 1e-16) * 100.0)


def run_report(
    degrees: Iterable[int],
    logs: Path,
    use_lp_init: bool,
    lawson_steps: int,
    max_iter: int,
) -> Tuple[Path, Path]:
    logs.mkdir(parents=True, exist_ok=True)
    csv_path = logs / "equiosc_report.csv"
    md_path = logs / "equiosc_report.md"
    records: List[Dict[str, object]] = []
    for name, (func, tol) in FUNCS.items():
        for n in degrees:
            result = remez_minimax(
                func,
                n,
                a=-1.0,
                b=1.0,
                eq_tol=tol,
                use_lp_init=use_lp_init,
                lawson_polish_steps=lawson_steps,
                max_iter=max_iter,
            )
            peaks_x, peaks_r = result.history["extremals"][-1]
            eq_ok = equioscillation_ok((peaks_x, peaks_r), tol_ratio=tol, expect=n + 2)
            spread = _percent_spread(peaks_r)
            records.append(
                {
                    "function": name,
                    "degree": n,
                    "equiosc_ok": eq_ok,
                    "E": result.E,
                    "peak_spread_pct": spread,
                    "iterations": len(result.history["E"]),
                }
            )
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        writer.writeheader()
        writer.writerows(records)
    with md_path.open("w") as f:
        f.write("| Function | n | Equiosc | E | Peak spread (%) | Iterations |\n")
        f.write("| --- | ---: | :---: | ---: | ---: | ---: |\n")
        for rec in records:
            f.write(
                f"| {rec['function']} | {rec['degree']} | {'✅' if rec['equiosc_ok'] else '❌'} | "
                f"{rec['E']:.6e} | {rec['peak_spread_pct']:.3f} | {rec['iterations']} |\n"
            )
    return csv_path, md_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate equioscillation report")
    parser.add_argument("--degrees", type=int, nargs="*", default=[20, 50, 100])
    parser.add_argument("--logs", type=Path, default=Path("experiments/logs"))
    parser.add_argument("--no-lp-init", action="store_true")
    parser.add_argument("--lawson-steps", type=int, default=5)
    parser.add_argument("--max-iter", type=int, default=40)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    csv_path, md_path = run_report(
        degrees=args.degrees,
        logs=args.logs,
        use_lp_init=not args.no_lp_init,
        lawson_steps=args.lawson_steps,
        max_iter=args.max_iter,
    )
    print(f"Report CSV written to {csv_path}")
    print(f"Markdown table written to {md_path}")


if __name__ == "__main__":
    main()
