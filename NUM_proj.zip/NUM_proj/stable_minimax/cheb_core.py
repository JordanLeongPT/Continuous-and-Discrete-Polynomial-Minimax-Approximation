from __future__ import annotations

from typing import Callable, Dict, Tuple

import numpy as np
from numpy.typing import ArrayLike
from scipy.fft import dct

from minimax.cheb import affine_to_cheb, cheb_lobatto, clenshaw

__all__ = [
    "affine_to_cheb",
    "cheb_nodes",
    "chebfit_dct_stable",
    "cheb_eval_on_ab",
]


def cheb_nodes(m: int) -> np.ndarray:
    """Return m Chebyshev–Lobatto nodes on [-1, 1]."""

    if m < 2:
        raise ValueError("m must be >= 2 for Chebyshev–Lobatto nodes")
    # minimax.cheb.cheb_lobatto expects m-1 as degree, returns m nodes
    return cheb_lobatto(m - 1)


def chebfit_dct_stable(
    f: Callable[[np.ndarray], np.ndarray],
    n: int,
    m: int = 4097,
    a: float = -1.0,
    b: float = 1.0,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """Stable Chebyshev fit via DCT with simple tail error estimates.

    Parameters
    ----------
    f : callable
        Function of x on [a,b].
    n : int
        Polynomial degree of approximation.
    m : int, optional
        Number of Chebyshev–Lobatto nodes (m > n).
    a, b : float
        Interval endpoints.

    Returns
    -------
    coeffs : ndarray, shape (n+1,)
        Chebyshev coefficients for p in T_k basis.
    stats : dict
        Contains tail estimates ("tail_l2", "tail_l1") and "m".
    """

    if m <= n + 1:
        raise ValueError("sampling grid size m must exceed degree n+1")
    x2t, t2x = affine_to_cheb(a, b)
    t_nodes = cheb_nodes(m)
    x_nodes = t2x(t_nodes)
    values = np.asarray(f(x_nodes), dtype=float)

    # DCT-I on Lobatto grid, matching minimax.cheb.chebfit_dct convention
    coeffs_full = dct(values, type=1) / (m - 1)
    coeffs_full[0] *= 0.5
    coeffs_full[-1] *= 0.5

    coeffs = coeffs_full[: n + 1].copy()
    tail = coeffs_full[n + 1 :]
    tail_l2 = float(np.sqrt(np.sum(tail * tail))) if tail.size else 0.0
    tail_l1 = float(np.sum(np.abs(tail))) if tail.size else 0.0
    stats = {"tail_l2": tail_l2, "tail_l1": tail_l1, "m": float(m)}
    return coeffs, stats


def cheb_eval_on_ab(c: ArrayLike, x: ArrayLike, a: float, b: float) -> np.ndarray:
    """Evaluate Chebyshev series with coefficients c on [a,b] via Clenshaw."""

    x2t, _ = affine_to_cheb(a, b)
    t = x2t(x)
    return clenshaw(np.asarray(c, dtype=float), t)


