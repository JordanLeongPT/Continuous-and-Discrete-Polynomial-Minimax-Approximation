from __future__ import annotations

import dataclasses
from typing import Callable, Dict, List

import numpy as np

from .cheb_core import affine_to_cheb, chebfit_dct_stable, cheb_eval_on_ab
from minimax import remez_minimax
from minimax.spectral_extrema import residual_extrema_spectral
from minimax.utils import equioscillation_ok, pick_alternating_peaks


@dataclasses.dataclass
class ContUniformResult:
    coeffs: np.ndarray
    E: float
    a: float
    b: float
    m_used: int
    history: Dict[str, List]


def uniform_approx_continuous(
    f: Callable[[np.ndarray], np.ndarray],
    n: int,
    a: float = -1.0,
    b: float = 1.0,
    m_init: int = 2049,
    m_max: int = 16385,
    tol: float = 1e-10,
    monitor_M: int = 200001,
    do_lawson: bool = False,
    remez_refine: bool = True,
    remez_eq_tol: float = 0.05,
    remez_max_iter: int = 60,
) -> ContUniformResult:
    """Continuous near-minimax approximation via Chebyshev DCT + optional Lawson.

    This routine aims for stability first:
    - Use increasingly dense Chebyshev–Lobatto grids and DCT to get coefficients.
    - Estimate error on a fixed dense monitor grid.
    - Optionally apply a few Lawson steps on a discrete grid as polishing.
    - Optionally run a short Remez refinement if equioscillation is poor.
    """

    if n < 0:
        raise ValueError("degree must be non-negative")
    if m_init <= n + 1:
        m_init = 2 * (n + 1) + 1

    m = m_init
    history: Dict[str, List] = {"E": [], "m": [], "tail_l2": [], "tail_l1": []}
    history["equiosc_ok"] = []
    history["equiosc_spread"] = []
    history["selected"] = []
    best_coeffs: np.ndarray | None = None
    best_E = np.inf
    best_m = m

    x_monitor = np.linspace(a, b, monitor_M)
    y_monitor = np.asarray(f(x_monitor), dtype=float)

    while True:
        coeffs, stats = chebfit_dct_stable(f, n, m=m, a=a, b=b)
        approx = cheb_eval_on_ab(coeffs, x_monitor, a, b)
        residual = y_monitor - approx
        E = float(np.max(np.abs(residual)))

        history["E"].append(E)
        history["m"].append(m)
        history["tail_l2"].append(stats["tail_l2"])
        history["tail_l1"].append(stats["tail_l1"])

        if E < best_E:
            best_E = E
            best_coeffs = coeffs.copy()
            best_m = m

        # crude equioscillation check on current coefficients to decide refinement
        p_eval = lambda x: cheb_eval_on_ab(coeffs, x, a, b)
        try:
            candidates = residual_extrema_spectral(lambda x: np.asarray(f(x), dtype=float), p_eval, a, b, M=min(8193, max(2049, 2 * m)))
            peaks_x, _ = pick_alternating_peaks(candidates, n)
            peaks_r = np.asarray(f(peaks_x), dtype=float) - p_eval(peaks_x)
            eq_ok = equioscillation_ok((peaks_x, peaks_r), tol_ratio=0.07, expect=n + 2)
            spread = float(
                (np.max(np.abs(peaks_r)) - np.min(np.abs(peaks_r)))
                / max(np.mean(np.abs(peaks_r)), 1e-16)
            )
        except Exception:
            eq_ok = False
            spread = np.inf
        history["equiosc_ok"].append(eq_ok)
        history["equiosc_spread"].append(spread)

        # stopping criteria: error and tail both small, or grid size limit reached
        if E <= tol or stats["tail_l2"] <= tol * 0.1 or m >= m_max:
            break

        # if tail hardly shrinks over last step, avoid over-refinement
        if len(history["tail_l2"]) >= 2:
            prev_tail = history["tail_l2"][-2]
            if prev_tail > 0:
                rel_tail = abs(stats["tail_l2"] - prev_tail) / prev_tail
                if rel_tail > -1e-3 and stats["tail_l2"] < tol:
                    break

        m = min(m_max, 2 * m - 1)

    coeffs = best_coeffs if best_coeffs is not None else coeffs

    # Optional Lawson polishing on discrete grid using existing minimax tools
    if do_lawson:
        try:
            from minimax.linf_lp import lawson_active_set

            x2t, _ = affine_to_cheb(a, b)
            approx = cheb_eval_on_ab(coeffs, x_monitor, a, b)
            residual = y_monitor - approx
            # choose worst n+2 points as initial active set
            idx = np.argsort(-np.abs(residual))[: n + 2]
            x_active = x_monitor[idx]
            f_vals = y_monitor[idx]
            coeffs_polish, tau_polish = lawson_active_set(
                x_active=x_active,
                f_vals=f_vals,
                coeffs_init=coeffs,
                x2t=x2t,
                max_steps=5,
            )
            approx_polish = cheb_eval_on_ab(coeffs_polish, x_monitor, a, b)
            E_polish = float(np.max(np.abs(y_monitor - approx_polish)))
            if E_polish < best_E:
                coeffs = coeffs_polish
                best_E = E_polish
                history["selected"].append("lawson")
        except Exception:
            # polishing is optional; ignore failures
            history["selected"].append("lawson_failed")

    # Optional Remez refinement for poor equioscillation (helps non-smooth f)
    if remez_refine:
        trigger_remez = False
        if history["equiosc_ok"]:
            trigger_remez = (not history["equiosc_ok"][-1]) or history["equiosc_spread"][-1] > 0.2
        if trigger_remez:
            try:
                res_remez = remez_minimax(
                    lambda x: np.asarray(f(x), dtype=float),
                    n,
                    a=a,
                    b=b,
                    eq_tol=remez_eq_tol,
                    max_iter=remez_max_iter,
                    use_lp_init=True,
                    lawson_polish_steps=5,
                )
                approx_remez = cheb_eval_on_ab(res_remez.coeffs, x_monitor, a, b)
                E_remez = float(np.max(np.abs(y_monitor - approx_remez)))
                history.setdefault("remez_E", []).append(E_remez)
                if E_remez < best_E:
                    coeffs = res_remez.coeffs
                    best_E = E_remez
                    history["selected"].append("remez")
                else:
                    history["selected"].append("cheb")
            except Exception as exc:  # keep best coeffs if Remez fails
                history.setdefault("remez_error", []).append(str(exc))
                history["selected"].append("cheb")
        else:
            history["selected"].append("cheb")
    else:
        history["selected"].append("cheb")

    return ContUniformResult(
        coeffs=coeffs,
        E=best_E,
        a=a,
        b=b,
        m_used=best_m,
        history=history,
    )

