from __future__ import annotations

import argparse
from pathlib import Path
from typing import Callable, Dict, List, Tuple

import numpy as np
import matplotlib.pyplot as plt

from .cont_uniform import uniform_approx_continuous
from .disc_uniform import uniform_approx_discrete


FuncSpec = Tuple[Callable[[np.ndarray], np.ndarray], str]

FUNCS_CONT: Dict[str, FuncSpec] = {
    "exp": (np.exp, "exp(x)"),
    "abs": (np.abs, "|x|"),
    "sin20": (lambda x: np.sin(20.0 * x), "sin(20x)"),
}


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Stable minimax experiments (Chebyshev-based)")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    # continuous
    p_cont = subparsers.add_parser("cont", help="continuous Chebyshev-based approximations")
    p_cont.add_argument("--func", choices=list(FUNCS_CONT.keys()), default="exp")
    p_cont.add_argument("--degrees", type=int, nargs="*", default=[10, 20, 50, 100])
    p_cont.add_argument("--a", type=float, default=-1.0)
    p_cont.add_argument("--b", type=float, default=1.0)
    p_cont.add_argument("--tol", type=float, default=1e-10)
    p_cont.add_argument("--outdir", type=Path, default=Path("experiments/stable_cont"))
    p_cont.add_argument("--no-show", action="store_true")

    # discrete
    p_disc = subparsers.add_parser("disc", help="discrete l_inf approximations")
    p_disc.add_argument("--func", choices=list(FUNCS_CONT.keys()), default="exp")
    p_disc.add_argument("--Ns", type=int, nargs="*", default=[1000, 5000])
    p_disc.add_argument("--degree", type=int, default=50)
    p_disc.add_argument("--a", type=float, default=-1.0)
    p_disc.add_argument("--b", type=float, default=1.0)
    p_disc.add_argument("--outdir", type=Path, default=Path("experiments/stable_disc"))
    p_disc.add_argument("--no-show", action="store_true")

    return parser.parse_args()


def run_cont(args: argparse.Namespace) -> None:
    f, label = FUNCS_CONT[args.func]
    a, b = args.a, args.b
    outdir: Path = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)

    degrees: List[int] = sorted(set(args.degrees))
    E_vals: List[float] = []

    for n in degrees:
        print(f"[cont] func={label}, n={n}")
        res = uniform_approx_continuous(f, n, a=a, b=b, tol=args.tol)
        E_vals.append(res.E)
        print(f"  m_used={res.m_used}, E={res.E:.6e}")

    # E vs n
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.semilogy(degrees, E_vals, marker="o")
    ax.set_xlabel("degree n")
    ax.set_ylabel("max |f-p|")
    ax.set_title(f"Stable Chebyshev approximation, f={label}")
    ax.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    fig.savefig(outdir / f"E_vs_n_{args.func}.png", dpi=200)

    # residual for largest n
    n_max = degrees[-1]
    res_max = uniform_approx_continuous(f, n_max, a=a, b=b, tol=args.tol)
    x = np.linspace(a, b, 4000)
    y = f(x)
    from .cheb_core import cheb_eval_on_ab

    p = cheb_eval_on_ab(res_max.coeffs, x, a, b)
    r = p - y
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(x, r, lw=1.5)
    ax.axhline(0.0, color="k", linewidth=0.8, alpha=0.5)
    ax.set_xlabel("x")
    ax.set_ylabel("p(x) - f(x)")
    ax.set_title(f"Residual, f={label}, n={n_max}")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(outdir / f"residual_{args.func}_n{n_max}.png", dpi=200)

    if not args.no_show:
        plt.show()
    else:
        plt.close("all")


def run_disc(args: argparse.Namespace) -> None:
    f, label = FUNCS_CONT[args.func]
    a, b = args.a, args.b
    outdir: Path = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)

    Ns: List[int] = sorted(set(args.Ns))
    t_vals: List[float] = []

    for N in Ns:
        print(f"[disc] func={label}, N={N}, n={args.degree}")
        x = np.linspace(a, b, N)
        y = f(x)
        res = uniform_approx_discrete(x, y, args.degree, a=a, b=b, use_lawson=True)
        t_vals.append(res.t)
        print(f"  t*={res.t:.6e}, nit={res.nit}")

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(Ns, t_vals, marker="o")
    ax.set_xlabel("N (number of samples)")
    ax.set_ylabel("t* (discrete l_inf)")
    ax.set_title(f"Discrete stable minimax, f={label}, n={args.degree}")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(outdir / f"t_vs_N_{args.func}_n{args.degree}.png", dpi=200)

    if not args.no_show:
        plt.show()
    else:
        plt.close("all")


def main() -> None:
    args = _parse_args()
    if args.mode == "cont":
        run_cont(args)
    elif args.mode == "disc":
        run_disc(args)


if __name__ == "__main__":
    main()

