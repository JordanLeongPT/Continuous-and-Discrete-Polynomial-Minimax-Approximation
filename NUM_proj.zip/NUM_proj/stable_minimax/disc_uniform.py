from __future__ import annotations

import dataclasses
from typing import Dict, List, Optional

import numpy as np

from minimax import minimax_disc


@dataclasses.dataclass
class DiscUniformResult:
    coeffs: np.ndarray
    t: float
    a: float
    b: float
    nit: int
    status: str
    history: Dict[str, List]


def uniform_approx_discrete(
    x: np.ndarray,
    y: np.ndarray,
    n: int,
    a: Optional[float] = None,
    b: Optional[float] = None,
    max_iter: int = 2000,
    use_lawson: bool = True,
) -> DiscUniformResult:
    """Wrapper around minimax_disc focusing on stability and simple history.

    This function is intentionally thin: the existing minimax_disc implementation
    already uses HiGHS LP + optional Lawson polishing and is tested against
    dense Remez. We simply expose a clean result dataclass and small history.
    """

    res = minimax_disc(x, y, n, a=a, b=b, method="highs", max_iter=max_iter, use_lawson=use_lawson)
    if a is None:
        a = float(np.min(x))
    if b is None:
        b = float(np.max(x))
    history = {"t": [res.t]}
    return DiscUniformResult(
        coeffs=res.coeffs,
        t=res.t,
        a=a,
        b=b,
        nit=res.nit,
        status=res.status,
        history=history,
    )


