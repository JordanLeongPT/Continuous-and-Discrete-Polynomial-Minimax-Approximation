from __future__ import annotations

from typing import Callable, List, Sequence, Tuple

import numpy as np
from scipy.optimize import minimize_scalar

from .cheb import affine_to_cheb, barycentric_eval, cheb_diff_matrix, cheb_lobatto

__all__ = ["residual_extrema_spectral"]


def residual_extrema_spectral(
    f: Callable[[np.ndarray], np.ndarray],
    p_eval: Callable[[np.ndarray], np.ndarray],
    a: float,
    b: float,
    M: int = 4097,
    refine: str = "brent",
) -> List[Tuple[float, float]]:
    if M < 33:
        raise ValueError("M should be at least 33 for spectral differentiation")
    x2t, t2x = affine_to_cheb(a, b)
    nodes_t = cheb_lobatto(M - 1)
    nodes_x = t2x(nodes_t)
    values = np.asarray(f(nodes_x) - p_eval(nodes_x), dtype=float)
    # spectral derivative with respect to t; sign is enough to bracket extrema
    D_t = cheb_diff_matrix(M)
    r_prime_t = D_t @ values

    # start with Lobatto nodes as trivial candidates
    candidates: List[Tuple[float, float]] = [
        (float(xi), float(ri)) for xi, ri in zip(nodes_x, values)
    ]

    # use sign changes of r' to bracket interior extrema
    signs = np.sign(r_prime_t)
    # treat exact zeros conservatively as potential sign changes
    intervals: List[Tuple[float, float]] = []
    for i in range(M - 1):
        s0, s1 = signs[i], signs[i + 1]
        if s0 == 0.0 or s1 == 0.0 or s0 * s1 < 0.0:
            x_left = float(min(nodes_x[i], nodes_x[i + 1]))
            x_right = float(max(nodes_x[i], nodes_x[i + 1]))
            if x_right > x_left:
                intervals.append((x_left, x_right))
    # fallback: if derivative never changes sign (almost monotone residual),
    # scan all subintervals to be safe
    if not intervals:
        for i in range(M - 1):
            x_left = float(min(nodes_x[i], nodes_x[i + 1]))
            x_right = float(max(nodes_x[i], nodes_x[i + 1]))
            if x_right > x_left:
                intervals.append((x_left, x_right))

    weights = _cheb_weights(M)

    def r_eval_scalar(x: float) -> float:
        # map physical x to Chebyshev t for barycentric evaluation
        t = x2t(np.array([x], dtype=float))
        return float(barycentric_eval(t, nodes_t, values, weights=weights)[0])

    for left, right in intervals:
        if right <= left:
            continue
        if refine == "brent":
            objective = lambda z: -abs(r_eval_scalar(z))
            # tighter xatol to resolve sharp peaks in high-degree cases
            res = minimize_scalar(
                objective,
                bounds=(left, right),
                method="bounded",
                options={"xatol": max((right - left) * 1e-10, 1e-14)},
            )
            x_opt = float(np.clip(res.x, left, right))
        else:
            sample = np.linspace(left, right, 9)
            vals = np.array([r_eval_scalar(float(s)) for s in sample])
            x_opt = float(sample[int(np.argmax(np.abs(vals)))])
        r_val = r_eval_scalar(x_opt)
        candidates.append((x_opt, r_val))
    top_idx = np.argsort(-np.abs(values))[: 4 * (len(intervals) + 1)]
    for idx in top_idx:
        candidates.append((nodes_x[idx], values[idx]))
    unique = {}
    for x, r in candidates:
        if x in unique and abs(unique[x]) >= abs(r):
            continue
        unique[x] = r
    result = sorted(unique.items(), key=lambda item: item[0])
    return [(float(x), float(r)) for x, r in result]


def _cheb_weights(m: int) -> np.ndarray:
    weights = np.ones(m)
    weights[0] = 0.5
    weights[-1] = 0.5
    weights *= (-1.0) ** np.arange(m)
    return weights
