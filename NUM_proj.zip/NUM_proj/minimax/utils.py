from __future__ import annotations

import dataclasses
import time
from typing import Callable, Dict, Iterable, List, Sequence, Tuple

import numpy as np
from numpy.polynomial import Chebyshev
from numpy.typing import ArrayLike

__all__ = [
    "Timer",
    "normalize_columns",
    "pick_alternating_peaks",
    "equioscillation_ok",
    "assert_clenshaw_matches_numpy",
    "assert_unscale_roundtrip",
]


@dataclasses.dataclass
class Timer:
    label: str = ""

    def __enter__(self):
        self.start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.elapsed = time.perf_counter() - self.start
        return False


def normalize_columns(mat: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    if mat.ndim != 2:
        raise ValueError("normalize_columns expects a 2-D array")
    norms = np.linalg.norm(mat, axis=0)
    norms[norms == 0] = 1.0
    return mat / norms, norms


def pick_alternating_peaks(
    candidates: Sequence[Tuple[float, float]],
    n: int,
    tol: float = 0.0,
) -> Tuple[np.ndarray, np.ndarray]:
    if len(candidates) == 0:
        raise ValueError("no candidates provided")
    target = n + 2
    unique: Dict[float, float] = {}
    for x, r in candidates:
        x = float(x)
        r = float(r)
        if x in unique and abs(unique[x]) >= abs(r):
            continue
        unique[x] = r
    xs = np.array(sorted(unique.keys()), dtype=float)
    rs = np.array([unique[x] for x in xs], dtype=float)
    if xs.size < target:
        raise ValueError("insufficient candidate extrema")
    sorted_idx = list(np.argsort(-np.abs(rs)))
    selected: List[int] = []
    for idx in sorted_idx:
        if idx in selected:
            continue
        selected.append(int(idx))
        if len(selected) >= target:
            break
    # ensure endpoints present
    for endpoint in (0, xs.size - 1):
        if endpoint not in selected:
            selected.append(endpoint)
    selected = sorted(selected[:target])
    xs_sel = xs[selected]
    mags = np.maximum(np.abs(rs[selected]), 1e-18)
    start_sign = 1.0
    pattern = start_sign * ((-1.0) ** np.arange(xs_sel.size))
    rs_sel = pattern * mags
    return xs_sel, rs_sel


def equioscillation_ok(
    peaks: Iterable[Tuple[float, float]] | Tuple[np.ndarray, np.ndarray],
    tol_ratio: float = 0.03,
    expect: int | None = None,
) -> bool:
    if isinstance(peaks, tuple):
        _, values = peaks
        values = np.asarray(values, dtype=float)
    else:
        values = np.asarray([r for _, r in peaks], dtype=float)
    if values.size == 0:
        return False
    if expect is not None and values.size != expect:
        return False
    signs = np.sign(values)
    if np.any(signs == 0):
        return False
    if not np.all(signs[:-1] * signs[1:] < 0):
        return False
    amps = np.abs(values)
    if np.any(amps == 0):
        return False
    spread = np.max(amps) - np.min(amps)
    mean_amp = np.mean(amps)
    return spread <= tol_ratio * mean_amp


def assert_clenshaw_matches_numpy(c: ArrayLike, t: ArrayLike, tol: float = 1e-12) -> None:
    from .cheb import clenshaw

    c = np.asarray(c, dtype=float)
    t = np.asarray(t, dtype=float)
    diff = np.max(np.abs(clenshaw(c, t) - Chebyshev(c)(t)))
    assert diff < tol, f"clenshaw vs numpy mismatch: {diff}"


def assert_unscale_roundtrip(A: np.ndarray, b: np.ndarray, solver: Callable[[np.ndarray, np.ndarray], Tuple[np.ndarray, float, np.ndarray]]) -> None:
    result = solver(A, b)
    if len(result) == 4:
        c, E, scales, _ = result
    else:
        c, E, scales = result
    reconstructed = np.concatenate([c, [E]]) * scales
    assert reconstructed.shape[0] == A.shape[1], "dimension mismatch after scaling roundtrip"
