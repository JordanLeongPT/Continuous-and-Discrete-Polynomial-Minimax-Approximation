"""Minimax polynomial approximation toolkit (continuous + discrete)."""

from .cheb import (
    affine_to_cheb,
    barycentric_eval,
    chebT_all,
    cheb_diff_matrix,
    cheb_lobatto,
    chebfit_dct,
    chebval,
    clenshaw,
)
from .linf_lp import DiscMinimaxResult, minimax_disc
from .remez import MinimaxResult, remez_minimax

__all__ = [
    "MinimaxResult",
    "DiscMinimaxResult",
    "remez_minimax",
    "minimax_disc",
    "affine_to_cheb",
    "chebT_all",
    "cheb_lobatto",
    "chebfit_dct",
    "chebval",
    "clenshaw",
    "barycentric_eval",
    "cheb_diff_matrix",
]

__version__ = "0.2.0"

