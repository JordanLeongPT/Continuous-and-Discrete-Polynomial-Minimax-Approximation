from __future__ import annotations

import dataclasses
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
from scipy import sparse
from scipy.linalg import svd
from scipy.optimize import linprog

from .cheb import affine_to_cheb, chebT_all, cheb_lobatto
from .utils import normalize_columns

__all__ = [
    "DiscMinimaxResult",
    "minimax_disc",
    "lp_init_on_lobatto",
    "lawson_active_set",
]


@dataclasses.dataclass
class DiscMinimaxResult:
    coeffs: np.ndarray
    t: float
    active_idx: np.ndarray
    status: str
    nit: int
    history: Dict[str, List]


def minimax_disc(
    x: np.ndarray,
    y: np.ndarray,
    n: int,
    a: Optional[float] = None,
    b: Optional[float] = None,
    method: str = "highs",
    max_iter: int = 1024,
    use_lawson: bool = False,
) -> DiscMinimaxResult:
    if x.shape != y.shape:
        raise ValueError("x and y must have identical shapes")
    if n < 0:
        raise ValueError("degree must be non-negative")
    if a is None:
        a = float(np.min(x))
    if b is None:
        b = float(np.max(x))
    x2t, _ = affine_to_cheb(a, b)
    t = x2t(x)
    T = chebT_all(n, t).T
    coeffs, tau, status, nit = _solve_linf_lp(T, y, method=method, max_iter=max_iter)
    residual = y - T @ coeffs
    active = np.argsort(-np.abs(residual))[: n + 2]
    history = {"tau": [tau]}
    sup_current = float(np.max(np.abs(residual)))
    if use_lawson and active.size >= n + 2:
        coeffs_polish, tau_polish = lawson_active_set(
            x_active=x[active],
            f_vals=y[active],
            coeffs_init=coeffs,
            x2t=x2t,
            max_steps=10,
        )
        residual_polish = y - T @ coeffs_polish
        sup_polish = float(np.max(np.abs(residual_polish)))
        if sup_polish < sup_current - 1e-12:
            coeffs = coeffs_polish
            tau = sup_polish
            sup_current = sup_polish
            history["tau"].append(sup_polish)
    return DiscMinimaxResult(coeffs=coeffs, t=sup_current, active_idx=active, status=status, nit=nit, history=history)


def lp_init_on_lobatto(
    f: Callable[[np.ndarray], np.ndarray],
    n: int,
    a: float,
    b: float,
    M: int = 2049,
) -> Tuple[np.ndarray, float]:
    x2t, t2x = affine_to_cheb(a, b)
    nodes_t = cheb_lobatto(M - 1)
    nodes_x = t2x(nodes_t)
    values = np.asarray(f(nodes_x), dtype=float)
    T = chebT_all(n, nodes_t).T
    coeffs, tau, _, _ = _solve_linf_lp(T, values, method="highs", max_iter=4000)
    return coeffs, tau


def lawson_active_set(
    x_active: np.ndarray,
    f_vals: np.ndarray,
    coeffs_init: np.ndarray,
    x2t: Callable[[np.ndarray], np.ndarray],
    max_steps: int = 10,
) -> Tuple[np.ndarray, float]:
    order = np.argsort(x_active)
    x_sorted = np.asarray(x_active, dtype=float)[order]
    f_sorted = np.asarray(f_vals, dtype=float)[order]
    coeffs = coeffs_init.copy()
    best_coeffs = coeffs.copy()
    best_tau = np.inf
    n = len(coeffs) - 1
    for _ in range(max_steps):
        t = x2t(x_sorted)
        T = chebT_all(n, t).T
        residual = f_sorted - T @ coeffs
        signs = np.sign(residual)
        signs[signs == 0] = 1.0
        signs = signs[0] * ((-1.0) ** np.arange(signs.size))
        A = np.column_stack([T, signs])
        A_scaled, scales = normalize_columns(A.copy())
        try:
            sol = np.linalg.lstsq(A_scaled, f_sorted, rcond=None)[0]
        except np.linalg.LinAlgError:
            u, s, vh = svd(A_scaled, full_matrices=False)
            sol = vh.T @ (u.T @ f_sorted / s)
        sol = sol / scales
        coeffs = sol[:-1]
        tau = abs(sol[-1])
        if tau < best_tau - 1e-12:
            best_tau = tau
            best_coeffs = coeffs.copy()
        else:
            break
    return best_coeffs, best_tau


def _solve_linf_lp(
    T: np.ndarray,
    y: np.ndarray,
    method: str,
    max_iter: int,
) -> Tuple[np.ndarray, float, str, int]:
    N, m = T.shape
    tau_col = -np.ones((N, 1))
    T_sparse = sparse.csr_matrix(T)
    tau_sparse = sparse.csr_matrix(tau_col)
    A_ub = sparse.vstack(
        [
            sparse.hstack([T_sparse, tau_sparse]),
            sparse.hstack([-T_sparse, tau_sparse]),
        ]
    ).tocsc()
    b_ub = np.concatenate([y, -y])
    c_vec = np.zeros(m + 1)
    c_vec[-1] = 1.0
    bounds = [(None, None)] * m + [(0.0, None)]
    res = linprog(
        c_vec,
        A_ub=A_ub,
        b_ub=b_ub,
        bounds=bounds,
        method=method,
        options={"maxiter": max_iter},
    )
    if not res.success:
        raise RuntimeError(f"linprog failed: {res.message}")
    coeffs = res.x[:-1]
    tau = float(res.x[-1])
    return coeffs, tau, res.status, res.nit
