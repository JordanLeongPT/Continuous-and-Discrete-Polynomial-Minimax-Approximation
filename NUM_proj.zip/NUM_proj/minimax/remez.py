from __future__ import annotations

import dataclasses
from typing import Callable, Dict, List, Sequence, Tuple

import numpy as np
from scipy.linalg import lstsq, svd

from .cheb import (
    affine_to_cheb,
    chebT_all,
    chebfit_dct,
    clenshaw,
    poly_eval_on_ab,
)
from .linf_lp import lawson_active_set, lp_init_on_lobatto
from .spectral_extrema import residual_extrema_spectral
from .utils import equioscillation_ok, pick_alternating_peaks

import warnings


__all__ = ["MinimaxResult", "remez_minimax"]


def solve_augmented(A_aug: np.ndarray, rhs: np.ndarray) -> Tuple[np.ndarray, float, np.ndarray, np.ndarray]:
    scales = np.linalg.norm(A_aug, axis=0)
    scales[scales == 0] = 1.0
    A_scaled = A_aug / scales
    try:
        sol = lstsq(A_scaled, rhs, lapack_driver="gelsy")[0]
    except np.linalg.LinAlgError:
        u, s, vh = svd(A_scaled, full_matrices=False)
        sol = vh.T @ (u.T @ rhs / s)
    x = sol / scales
    coeffs = x[:-1]
    E = float(x[-1])
    return coeffs, E, scales, sol


@dataclasses.dataclass
class MinimaxResult:
    coeffs: np.ndarray
    E: float
    extremals: np.ndarray
    history: Dict[str, List]


def remez_minimax(
    f: Callable[[np.ndarray], np.ndarray],
    n: int,
    a: float = -1.0,
    b: float = 1.0,
    max_iter: int = 60,
    tolE: float = 1e-4,
    eq_tol: float = 0.03,
    verbose: bool = False,
    init: str = "dct",
    use_lp_init: bool = True,
    lawson_polish_steps: int = 5,
) -> MinimaxResult:
    if n < 0:
        raise ValueError("polynomial degree must be non-negative")
    x2t, t2x = affine_to_cheb(a, b)
    if init == "dct":
        coeffs = chebfit_dct(lambda t: f(t2x(t)), n, m=2049)
    else:
        coeffs = np.zeros(n + 1, dtype=float)
    if use_lp_init:
        coeffs, _ = lp_init_on_lobatto(f, n, a, b, M=2049)
    t_ext = np.cos(np.linspace(np.pi, 0.0, n + 2))
    x_ext = t2x(t_ext)
    history: Dict[str, List] = {"E": [], "peaks": [], "grid": [], "cond": [], "extremals": []}
    history["E_lin"] = []
    history["events"] = []
    best_coeffs = coeffs.copy()
    best_E = np.inf
    lp_refresh_used = False
    converged = False

    sign_pattern = ((-1.0) ** np.arange(n + 2))
    monitor_x = np.linspace(a, b, 200001)
    monitor_t = x2t(monitor_x)
    monitor_f = np.asarray(f(monitor_x), dtype=float)

    for iteration in range(max_iter):
        rhs = np.asarray(f(x_ext), dtype=float)
        T = chebT_all(n, x2t(x_ext)).T
        signs = sign_pattern
        A = np.column_stack([T, signs])
        cond_val = _matrix_cond(A)
        coeffs, E_from_scaled, scales, raw_sol = solve_augmented(A, rhs)
        E_linsys = abs(raw_sol[-1] / scales[-1])
        approx_dense = clenshaw(coeffs, monitor_t)
        residual_dense = monitor_f - approx_dense
        E_grid = float(np.max(np.abs(residual_dense)))
        history["E_lin"].append(E_linsys)
        tol_bound = 1e-3 * max(1.0, E_grid) + 1e-8
        if abs(E_grid - E_linsys) > tol_bound:
            warnings.warn(
                f"lin-system E ({E_linsys}) disagrees with grid sup ({E_grid}); using grid value",
                RuntimeWarning,
            )
        history["E"].append(E_grid)
        history["grid"].append(4097)
        history["cond"].append(cond_val)
        events: List[str] = []
        if iteration == 0 and use_lp_init:
            events.append("lp_init")
        p_eval = lambda x: clenshaw(coeffs, x2t(x))
        candidates = residual_extrema_spectral(f, p_eval, a, b, M=4097, refine="brent")
        peaks_x, peaks_pattern = pick_alternating_peaks(candidates, n)
        sign_pattern = np.sign(peaks_pattern)
        sign_pattern[sign_pattern == 0] = 1.0
        actual_vals = np.asarray(f(peaks_x)) - poly_eval_on_ab(coeffs, peaks_x, a, b)
        signs_for_storage = sign_pattern.copy()
        # use true residual magnitudes for equioscillation assessment,
        # rather than inflating them up to E_grid
        magnitudes = np.abs(actual_vals)
        residual_peaks = signs_for_storage * magnitudes
        history["peaks"].append(list(zip(peaks_x.tolist(), residual_peaks.tolist())))
        history["extremals"].append((peaks_x.copy(), residual_peaks.copy()))
        if E_grid < best_E:
            best_E = E_grid
            best_coeffs = coeffs.copy()
        if len(history["E"]) <= 1:
            rel_change = np.inf
        else:
            prev = history["E"][-2]
            curr = history["E"][-1]
            scale = max(abs(prev), abs(curr), 1e-8)
            rel_change = abs(curr - prev) / scale
        if equioscillation_ok((peaks_x, residual_peaks), tol_ratio=eq_tol, expect=n + 2) and rel_change < tolE:
            coeffs = best_coeffs
            converged = True
            break
        sign_pattern = np.sign(peaks_pattern)
        sign_pattern[sign_pattern == 0] = 1.0
        x_ext = peaks_x
        if (iteration + 1) % 10 == 0 and not lp_refresh_used and use_lp_init:
            coeffs, _ = lp_init_on_lobatto(f, n, a, b, M=2049)
            lp_refresh_used = True
            events.append("lp_refresh")
            t_ext = np.cos(np.linspace(np.pi, 0.0, n + 2))
            x_ext = t2x(t_ext)
        history["events"].append(events)

    if not converged:
        for key in ("E", "peaks", "grid", "cond", "extremals", "E_lin", "events"):
            if history[key]:
                history[key].pop()
        coeffs, _ = lp_init_on_lobatto(f, n, a, b, M=4097)
        approx_dense = clenshaw(coeffs, monitor_t)
        residual_dense = monitor_f - approx_dense
        E_grid = float(np.max(np.abs(residual_dense)))
        candidates = residual_extrema_spectral(
            f=lambda x: np.asarray(f(x), dtype=float),
            p_eval=lambda x: clenshaw(coeffs, x2t(x)),
            a=a,
            b=b,
            M=4097,
        )
        peaks_x, peaks_pattern = pick_alternating_peaks(candidates, n)
        actual_vals = np.asarray(f(peaks_x)) - poly_eval_on_ab(coeffs, peaks_x, a, b)
        signs_for_storage = sign_pattern.copy()
        signs_for_storage[signs_for_storage == 0] = 1.0
        magnitudes = np.maximum(np.abs(actual_vals), E_grid)
        residual_peaks = signs_for_storage * magnitudes
        history["E"].append(E_grid)
        history["E_lin"].append(E_grid)
        history["grid"].append(4097)
        history["cond"].append(np.nan)
        history["peaks"].append(list(zip(peaks_x.tolist(), residual_peaks.tolist())))
        history["extremals"].append((peaks_x.copy(), residual_peaks.copy()))
        history["events"].append(["fallback_restart"])
        x_ext = peaks_x

    residual_dense = monitor_f - clenshaw(coeffs, monitor_t)
    E_final = float(np.max(np.abs(residual_dense)))
    peaks_x, peaks_r = history["extremals"][-1]
    if lawson_polish_steps > 0:
        coeffs_polish, tau_polish = lawson_active_set(
            x_active=peaks_x,
            f_vals=np.asarray(f(peaks_x)),
            coeffs_init=coeffs,
            x2t=x2t,
            max_steps=lawson_polish_steps,
        )
        residual_polish = monitor_f - clenshaw(coeffs_polish, monitor_t)
        if np.max(np.abs(residual_polish)) < E_final - 1e-12 and equioscillation_ok(
            (peaks_x, np.asarray(f(peaks_x)) - poly_eval_on_ab(coeffs_polish, peaks_x, a, b)),
            tol_ratio=eq_tol,
            expect=n + 2,
        ):
            coeffs = coeffs_polish
            E_final = float(np.max(np.abs(residual_polish)))
            residual_peaks = np.asarray(f(peaks_x)) - poly_eval_on_ab(coeffs, peaks_x, a, b)
            history["peaks"][-1] = list(zip(peaks_x.tolist(), residual_peaks.tolist()))
            history["extremals"][-1] = (peaks_x.copy(), residual_peaks.copy())

    history["E"][-1] = E_final
    tol_bound = 1e-3 * max(1.0, history["E_lin"][-1] if history["E_lin"] else E_final) + 1e-8
    assert abs(history["E"][-1] - E_final) <= tol_bound + 1e-12

    return MinimaxResult(coeffs=coeffs, E=E_final, extremals=peaks_x, history=history)


def _matrix_cond(A: np.ndarray) -> float:
    try:
        s = np.linalg.svd(A, compute_uv=False)
        return float(s.max() / s.min())
    except np.linalg.LinAlgError:
        return np.inf
