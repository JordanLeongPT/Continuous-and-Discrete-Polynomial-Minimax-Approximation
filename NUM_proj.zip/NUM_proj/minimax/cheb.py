from __future__ import annotations

from typing import Callable, Tuple

import numpy as np
from numpy.typing import ArrayLike
from scipy.fft import dct
from numpy.polynomial import Chebyshev

__all__ = [
    "affine_to_cheb",
    "chebT_all",
    "clenshaw",
    "chebval",
    "poly_eval_on_ab",
    "chebval_numpy",
    "chebder_coeffs",
    "cheb_lobatto",
    "cheb_diff_matrix",
    "barycentric_eval",
    "chebfit_dct",
]


def affine_to_cheb(a: float, b: float) -> Tuple[Callable[[ArrayLike], np.ndarray], Callable[[ArrayLike], np.ndarray]]:
    if a == b:
        raise ValueError("interval endpoints must differ")
    scale = 2.0 / (b - a)
    shift = -(a + b) / (b - a)

    def x2t(x: ArrayLike) -> np.ndarray:
        return scale * np.asarray(x, dtype=float) + shift

    def t2x(t: ArrayLike) -> np.ndarray:
        return 0.5 * (b - a) * np.asarray(t, dtype=float) + 0.5 * (a + b)

    return x2t, t2x


def cheb_lobatto(m: int) -> np.ndarray:
    if m < 1:
        raise ValueError("m must be >= 1")
    k = np.arange(0, m + 1)
    return np.cos(np.pi * k / m)


def chebT_all(n: int, t: ArrayLike) -> np.ndarray:
    t = np.asarray(t, dtype=float)
    out = np.empty((n + 1, t.size), dtype=float)
    out[0] = 1.0
    if n == 0:
        return out
    out[1] = t
    for k in range(1, n):
        out[k + 1] = 2.0 * t * out[k] - out[k - 1]
    return out


def clenshaw(c: ArrayLike, t: ArrayLike) -> np.ndarray:
    c = np.asarray(c, dtype=float)
    t = np.asarray(t, dtype=float)
    b_k1 = np.zeros_like(t)
    b_k2 = np.zeros_like(t)
    for coeff in c[:0:-1]:
        b_k0 = 2.0 * t * b_k1 - b_k2 + coeff
        b_k2, b_k1 = b_k1, b_k0
    return c[0] + t * b_k1 - b_k2


def chebder_coeffs(c: ArrayLike, m: int = 1) -> np.ndarray:
    coeffs = np.asarray(c, dtype=float)
    for _ in range(m):
        n = len(coeffs) - 1
        if n <= 0:
            return np.zeros(1, dtype=float)
        deriv = np.zeros_like(coeffs)
        deriv[-2] = 2 * n * coeffs[-1]
        for k in range(n - 2, -1, -1):
            deriv[k] = deriv[k + 2] + 2 * (k + 1) * coeffs[k + 1]
        deriv[0] *= 0.5
        coeffs = deriv[:-1]
    return coeffs


def cheb_diff_matrix(m: int) -> np.ndarray:
    if m < 2:
        raise ValueError("need at least 2 Lobatto nodes for differentiation")
    n = m - 1
    x = cheb_lobatto(n)
    c = np.ones(m)
    c[0] = 2.0
    c[-1] = 2.0
    c *= (-1.0) ** np.arange(m)
    X = np.tile(x, (m, 1))
    dX = X - X.T
    dX += np.eye(m)
    C = np.outer(c, 1.0 / c)
    D = C / dX
    D -= np.diag(D.sum(axis=1))
    return D


def barycentric_eval(
    x: ArrayLike,
    nodes: np.ndarray,
    values: np.ndarray,
    weights: np.ndarray | None = None,
) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    nodes = np.asarray(nodes, dtype=float)
    values = np.asarray(values, dtype=float)
    if weights is None:
        weights = np.ones_like(nodes)
        weights[0] = 0.5
        weights[-1] = 0.5
        weights *= (-1.0) ** np.arange(nodes.size)
    out = np.empty_like(x, dtype=float)
    for idx, xi in enumerate(x):
        diff = xi - nodes
        close = np.isclose(diff, 0.0)
        if np.any(close):
            out[idx] = values[close][0]
            continue
        term = weights / diff
        out[idx] = np.sum(term * values) / np.sum(term)
    return out


def chebfit_dct(f: Callable[[np.ndarray], np.ndarray], n: int, m: int = 4097) -> np.ndarray:
    if m <= n:
        raise ValueError("sampling grid must exceed polynomial degree")
    nodes = cheb_lobatto(m - 1)
    vals = np.asarray(f(nodes), dtype=float)
    coeffs = dct(vals, type=1) / (m - 1)
    coeffs[0] *= 0.5
    coeffs[-1] *= 0.5
    return coeffs[: n + 1]


def chebval(c: ArrayLike, t: ArrayLike) -> np.ndarray:
    return clenshaw(c, t)


def poly_eval_on_ab(c: ArrayLike, x: ArrayLike, a: float, b: float) -> np.ndarray:
    x2t, _ = affine_to_cheb(a, b)
    t = x2t(x)
    return clenshaw(c, t)


def chebval_numpy(c: ArrayLike, t: ArrayLike) -> np.ndarray:
    return Chebyshev(np.asarray(c, dtype=float))(np.asarray(t, dtype=float))
