import numpy as np

from minimax.remez import solve_augmented
from minimax.utils import assert_unscale_roundtrip


def test_scaling_roundtrip_matches_true_solution():
    rng = np.random.default_rng(0)
    m, k = 40, 18
    A = rng.standard_normal((m, k))
    true_x = rng.standard_normal(k)
    b = A @ true_x
    coeffs, E, scales, raw_sol = solve_augmented(A, b)
    recovered = np.concatenate([coeffs, [E]])
    np.testing.assert_allclose(A @ recovered, b, atol=1e-10)
    assert_unscale_roundtrip(A, b, solve_augmented)
