import numpy as np

from minimax import minimax_disc, remez_minimax
from minimax.cheb import affine_to_cheb, clenshaw


def test_linf_lp_matches_dense_remez():
    x = np.linspace(-1.0, 1.0, 400)
    f = lambda t: np.cos(3.0 * t) - 0.3 * t
    y = f(x)
    degree = 10
    res_lp = minimax_disc(x, y, degree, a=-1.0, b=1.0, use_lawson=True)
    res_remez = remez_minimax(f, degree, eq_tol=0.03)
    x2t, _ = affine_to_cheb(-1.0, 1.0)
    approx_lp = clenshaw(res_lp.coeffs, x2t(x))
    approx_remez = clenshaw(res_remez.coeffs, x2t(x))
    err_lp = np.max(np.abs(y - approx_lp))
    err_remez = np.max(np.abs(y - approx_remez))
    assert abs(err_lp - err_remez) < 1e-6
