import numpy as np

from minimax import remez_minimax
from minimax.cheb import affine_to_cheb, clenshaw, poly_eval_on_ab, chebval_numpy
from minimax.utils import equioscillation_ok, assert_clenshaw_matches_numpy


def _sup_error(res, func, a=-1.0, b=1.0, m=200001):
    x = np.linspace(a, b, m)
    approx = poly_eval_on_ab(res.coeffs, x, a, b)
    return float(np.max(np.abs(func(x) - approx)))


def test_remez_equioscillation_exp():
    n = 20
    result = remez_minimax(np.exp, n, eq_tol=0.03, use_lp_init=True, lawson_polish_steps=5)
    assert equioscillation_ok(
        result.history["extremals"][-1],
        tol_ratio=0.03,
        expect=n + 2,
    )
    sup_dense = _sup_error(result, np.exp)
    assert abs(sup_dense - result.E) <= 1e-3 * max(1.0, abs(result.E)) + 1e-8


def test_remez_equioscillation_abs():
    n = 20
    func = np.abs
    result = remez_minimax(func, n, eq_tol=0.05, use_lp_init=True, lawson_polish_steps=5)
    assert equioscillation_ok(
        result.history["extremals"][-1],
        tol_ratio=0.05,
        expect=n + 2,
    )
    sup_dense = _sup_error(result, func)
    assert abs(sup_dense - result.E) <= 1e-3 * max(1.0, abs(result.E)) + 1e-8


def test_clenshaw_matches_numpy():
    rng = np.random.default_rng(42)
    for deg in (5, 20, 50):
        coeffs = rng.standard_normal(deg + 1)
        t = rng.uniform(-1.0, 1.0, size=128)
        assert_clenshaw_matches_numpy(coeffs, t)
