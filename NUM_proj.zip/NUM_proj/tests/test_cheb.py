import numpy as np
from numpy.polynomial import Chebyshev

from minimax.cheb import chebder_coeffs, chebval


def test_chebval_matches_numpy():
    rng = np.random.default_rng(1234)
    coeffs = rng.standard_normal(32)
    pts = rng.uniform(-1.0, 1.0, size=256)
    ours = chebval(coeffs, pts)
    ref = Chebyshev(coeffs)(pts)
    assert np.max(np.abs(ours - ref)) < 1e-12


def test_chebder_coeffs_matches_numpy():
    rng = np.random.default_rng(2024)
    coeffs = rng.standard_normal(20)
    ours = chebder_coeffs(coeffs)
    ref = Chebyshev(coeffs).deriv().coef
    assert np.max(np.abs(ours - ref)) < 1e-12

